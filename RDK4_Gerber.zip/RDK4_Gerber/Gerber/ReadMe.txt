
Project RDK4 Rev2:
PCB dimensions 115.25x48mm.
4 Layers.
Thickness: 1.55mm FR4.
Mask color: Purple.
Silkscreen color: White.
Finish: Immersion Gold.
Vias: Tented. 